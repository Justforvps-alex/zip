<?php
exec("curl http://ovz4.alexdumachev.m2oon.vps.myjino.ru/main/check_url.php");
?>