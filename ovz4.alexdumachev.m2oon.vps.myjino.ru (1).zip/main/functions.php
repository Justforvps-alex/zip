<?php
function Curl_avito($url,$time_sleep,$mistakes)
{
	$useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'.rand(60,72).'.0.'.rand(1000,9999).'.121 Safari/537.36';
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_URL,$url);
	if(isset($proxy))
	{
		curl_setopt($ch, CURLOPT_PROXY, $proxy);
		curl_setopt($ch, CURLOPT_PROXYTYPE, $GLOBALS['proxy_type']);
	}

	
	        $cookie = [
            'u=2fgvungc.qhxzcu.g1mrdbtn8s',
            /*'_ym_uid=1554073340974296533',
            '_ym_d=1554073340',
            '_ga=GA1.2.814288055.1554073340',
            '_fbp=fb.1.1554073340437.824272448',
            'buyer_tooltip_location=0',
            'crto_uid=253dda0ab477a555420d3f405db1b3c7',
            '__gads=ID=74e89d17751b05a5:T=1554073430:S=ALNI_MbOKN2U3YrZqv9FNED47akb18Ha6A',
            'v=1554219350',
            'buyer_selected_search_radius0=200',
            'sx=H4sIAAAAAAACAwXB2wqAIAwA0H%2FZcw%2BaG4p%2FU0NmjBBZF0L8984ZUDSetXbdL8SkrzRJCa2ZQh7wQIbNQj%2Fc%2Bvm7qSGzMTcxEbUkygoLFMieCIOjSG7OH6TMtTtUAAAA',
            'dfp_group=59',
            'weborama-viewed=1',
            'abp=1',
            '_gid=GA1.2.1539975770.1554219347',
            '_ym_visorc_34241905=w',
            'f=5.0c4f4b6d233fb90636b4dd61b04726f147e1eada7172e06c47e1eada7172e06c47e1eada7172e06c47e1eada7172e06cb59320d6eb6303c1b59320d6eb6303c1b59320d6eb6303c147e1eada7172e06c8a38e2c5b3e08b898a38e2c5b3e08b890df103df0c26013a0df103df0c26013a2ebf3cb6fd35a0ac0df103df0c26013a8b1472fe2f9ba6b984dcacfe8ebe897bfa4d7ea84258c63d59c9621b2c0fa58f897baa7410138ead3de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe207b7a18108a6dcd6f8ee35c29834d631c9ba923b7b327da7e87a84e371fc60d21abab15028c5344d5e61d702b2ac73f71c754c08cff1b841be955198f1b1b5bd9b875d7b97b5db61daa659585eecd48d4938c41efda3055a8f1786dad6fd98129e82118971f2ed64956cdff3d4067aa5091ac58b0b2b290b3d84c5444fc776a33de19da9ed218fe23de19da9ed218fe2e5c2340ab6d15e6006adf30cf986c8a3263e604e6466ce4c',
            '_ym_isad=1',
            'rheftjdd=rheftjddVal',
            'anid=removed',
            'sessid=3ad5faaa9b1944f3ef0b88dcd9ecf5c2.1554219713',
            'buyer_location_id=648630',*/
        ];

        $headers = array(
            ':authority: www.avito.ru',
            ':method: GET',
            ':path: '.str_replace('https://www.avito.ru', '', $url),
            ':scheme: https',
            'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            //'accept-encoding: gzip, deflate, br',
            'accept-language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7,de;q=0.6,vi;q=0.5',
            'cache-control: max-age=0',
            'cookie: '.implode('; ', $cookie),
            'upgrade-insecure-requests: 1',
            'referer: '.$url,
            'user-agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'.rand(60,72).'.0.'.rand(1000,9999).'.121 Safari/537.36'
        );
    //curl_setopt($ch, CURLOPT_PROXYHEADER, $headers);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	//curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	$page = curl_exec($ch);
	curl_close($ch);
	$html=str_get_html($page);
	//fwrite($proxy_mistakes, $html);
	//echo $html;
	fwrite($mistakes, "<br><br>Вступавет проверочка<br>");
	sleep($time_sleep);
	$html=check_html($html,$url,$mistakes);
	//echo "<br><br><br><br>Верный хтмл только этот стоп<br><br>м".$html."<br><br><br>";
	return $html;
}
function check_html($html,$url,$mistakes)
{
    $string_proxy=$GLOBALS['number_proxy'];
    if(!isset($string_proxy) or $string_proxy==''){$GLOBALS['number_proxy']=1; $GLOBALS['proxy_type']='CURLPROXY_SOCKS4';}
	$check_html=$html;
	//echo "<br>".$url."<br>";
	$check_1=strpos($check_html,'Объявления');
	$check_2=strpos($check_html,'user_unauth');
	$check_3=strpos($check_html,'image64');
	if($check_html!='')
	{
	if($check_1!==false or $check_2!==false or $check_3!==false) {fwrite($mistakes, "<br>Vse norm<br>"); $check_proxy_check=1;}
	else {fwrite($mistakes, "<br>Vse ploho, zabanen<br>");}
	}
	else {fwrite($mistakes, "<br>Vse ploho, dead proxy<br>");$check_proxy_check=0;}
	while($check_html=='' or $check_proxy_check==0)
	{
	//Проверка сигналов
    $signal=htmlentities(file_get_contents("signal.txt"));
    if($signal=="stop")
        {
        $php_status = fopen('phpstatus.txt', 'w+');
        fwrite($php_status, "done");
        fclose($php_status);
        exit;
        }
        
	$check_1=strpos($check_html,'Объявления');
	$check_2=strpos($check_html,'user_unauth');
	$check_3=strpos($check_html,'image64');
	if($check_html!='')
	{
    	if($check_1!==false or $check_2!==false or $check_3!==false) {fwrite($mistakes,"<br>Vse norm<br>"); $check_proxy_check=1; break;}
    	else {fwrite($mistakes,"<br>Vse ploho, zabanen<br>");}
	}
	else {fwrite($mistakes,"<br>Vse ploho, dead proxy<br>");}
	$useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'.rand(60,72).'.0.'.rand(1000,9999).'.121 Safari/537.36';
	$show_info = file('socks5_proxies.txt');
	$proxy=$show_info[$string_proxy];
	if($proxy='' or $proxy=NULL)
	{
	$url_proxy='https://api.proxyscrape.com/?request=getproxies&proxytype=socks5&timeout=10000&country=all';
    download_proxy($url_proxy);
    $GLOBALS['proxy_type']='CURLPROXY_SOCKS5';
    $GLOBALS['number_proxy']=1;
    $show_info = file('socks5_proxies.txt');
	$proxy=$show_info[1];
	}
	$proxy_mistakes = fopen('peoxy.txt', 'a+');
	fwrite($proxy_mistakes, $string_proxy." next");
	fclose($proxy_mistakes);
	$statusfp = fopen('status.txt', 'w+');
    fwrite($statusfp, "IP забанен, подключаемся к прокси");
    fclose($statusfp);
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_PROXY, $proxy);
    curl_setopt($ch, CURLOPT_PROXYTYPE, $GLOBALS['proxy_type']);
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	//curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
		        $cookie = [
            'u=2fgvungc.qhxzcu.g1mrdbtn8s',
            /*'_ym_uid=1554073340974296533',
            '_ym_d=1554073340',
            '_ga=GA1.2.814288055.1554073340',
            '_fbp=fb.1.1554073340437.824272448',
            'buyer_tooltip_location=0',
            'crto_uid=253dda0ab477a555420d3f405db1b3c7',
            '__gads=ID=74e89d17751b05a5:T=1554073430:S=ALNI_MbOKN2U3YrZqv9FNED47akb18Ha6A',
            'v=1554219350',
            'buyer_selected_search_radius0=200',
            'sx=H4sIAAAAAAACAwXB2wqAIAwA0H%2FZcw%2BaG4p%2FU0NmjBBZF0L8984ZUDSetXbdL8SkrzRJCa2ZQh7wQIbNQj%2Fc%2Bvm7qSGzMTcxEbUkygoLFMieCIOjSG7OH6TMtTtUAAAA',
            'dfp_group=59',
            'weborama-viewed=1',
            'abp=1',
            '_gid=GA1.2.1539975770.1554219347',
            '_ym_visorc_34241905=w',
            'f=5.0c4f4b6d233fb90636b4dd61b04726f147e1eada7172e06c47e1eada7172e06c47e1eada7172e06c47e1eada7172e06cb59320d6eb6303c1b59320d6eb6303c1b59320d6eb6303c147e1eada7172e06c8a38e2c5b3e08b898a38e2c5b3e08b890df103df0c26013a0df103df0c26013a2ebf3cb6fd35a0ac0df103df0c26013a8b1472fe2f9ba6b984dcacfe8ebe897bfa4d7ea84258c63d59c9621b2c0fa58f897baa7410138ead3de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe23de19da9ed218fe207b7a18108a6dcd6f8ee35c29834d631c9ba923b7b327da7e87a84e371fc60d21abab15028c5344d5e61d702b2ac73f71c754c08cff1b841be955198f1b1b5bd9b875d7b97b5db61daa659585eecd48d4938c41efda3055a8f1786dad6fd98129e82118971f2ed64956cdff3d4067aa5091ac58b0b2b290b3d84c5444fc776a33de19da9ed218fe23de19da9ed218fe2e5c2340ab6d15e6006adf30cf986c8a3263e604e6466ce4c',
            '_ym_isad=1',
            'rheftjdd=rheftjddVal',
            'anid=removed',
            'sessid=3ad5faaa9b1944f3ef0b88dcd9ecf5c2.1554219713',
            'buyer_location_id=648630',*/
        ];

        $headers = array(
            ':authority: www.avito.ru',
            ':method: GET',
            ':path: '.str_replace('https://www.avito.ru', '', $url),
            ':scheme: https',
            'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            //'accept-encoding: gzip, deflate, br',
            'accept-language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7,de;q=0.6,vi;q=0.5',
            'cache-control: max-age=0',
            'cookie: '.implode('; ', $cookie),
            'upgrade-insecure-requests: 1',
            'referer: '.$url,
            'user-agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'.rand(60,72).'.0.'.rand(1000,9999).'.121 Safari/537.36'
        );
        
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_PROXYHEADER, $headers);
	$page = curl_exec($ch);
	curl_close($ch);
	$check_html=str_get_html($page);
	fwrite($mistakes, "<br><br>Плохой хтмл<br>");
	$string_proxy++;
    }
	//echo "<br>End of while<br>";
	$GLOBALS['number_proxy']=$string_proxy;
	sleep(7);
	return $check_html;
}
function find_phone_url($id, $phone_item_only0, $phone_item_only1, $phone_item_only2)
{
	$id_only=$id;
	$array_keys0 = str_split($phone_item_only0); 
	$array_keys1 = str_split($phone_item_only1);
	$array_keys2 = str_split($phone_item_only2);
	//function check_code($array0,$array1,$array2)
	$k=0; //Номер кода
	$code_key='';//Буква разделитель
	$letters_in_key=count($array_keys0);
	for($a=0;$a<$letters_in_key;$a=$a+3)
	{
		//Если все 3 совпадают
		if($array_keys0[$a]==$array_keys1[$a] and $array_keys0[$a]==$array_keys2[$a])
		{ continue; }
		//Проверка когда 2 отличаются
		elseif($array_keys0[$a]!=$array_keys1[$a] and $array_keys0[$a]!=$array_keys2[$a] and $array_keys1[$a]!=$array_keys2[$a])
		{
			if($array_keys0[$a+1]==$array_keys1[$a+1]) { $k=0; $code_key=$array_keys0[$a]; break;}
			elseif($array_keys0[$a+1]==$array_keys2[$a+1]) { $k=0; $code_key=$array_keys0[$a]; break;} 
			elseif($array_keys1[$a+1]==$array_keys2[$a+1]) { $k=1; $code_key=$array_keys1[$a]; break;}	
		}
		//Проверка когда 1 отличается
		elseif($array_keys0[$a]==$array_keys1[$a] and $array_keys0[$a]!=$array_keys2[$a])
		{
			$code_key=$array2[$a];
			if($array_keys0[$a]==$array_keys2[$a+1]) { $k=2; break;}	
		}
		elseif($array_keys0[$a]==$array_keys2[$a] and $array_keys0[$a]!=$array_keys1[$a])
		{
			$code_key=$array_keys1[$a];
			if($array_keys0[$a]==$array_keys1[$a+1]) { $k=1; break;}	
		}
		elseif($array_keys1[$a]==$array_keys2[$a] and $array_keys1[$a]!=$array_keys0[$a])
		{
			$code_key=$array_keys0[$a];
			if($array_keys1[$a]==$array_keys0[$a+1]) { $k=0; break;}	
		}
	}
	//Находим количество букв и вгоняем линию
	if($k==0) { $crypted_line_array=$array_keys0; }
	elseif($k==1) { $crypted_line_array=$array_keys1; }
	elseif($k==2) { $crypted_line_array=$array_keys2; }
	$numer=count($crypted_line_array);
	$findphone = fopen('phoneurls.txt', 'wb');
    fwrite($findphone, $k."  ".$numer."  ".$crypted_line_array." codekey: ".$code_key);
    fclose($findphone);
	$pkey=''; //Код
	//$i=0;
	for($i=0;$i<$numer;$i=$i+3)
	{
		if($crypted_line_array[$i]==$code_key) {$i++;}
		$pkey.=$crypted_line_array[$i];
	}
	$phoneUrl="https://www.avito.ru/items/phone/".$id_only."?pkey=".$pkey."&vsrc=r";
	//echo "<br>Вывод из поиска".$phoneUrl."<br>";
	return $phoneUrl;
}
function file_force_download($file) {
  if (file_exists($file)) {
    // сбрасываем буфер вывода PHP, чтобы избежать переполнения памяти выделенной под скрипт
    // если этого не сделать файл будет читаться в память полностью!
    if (ob_get_level()) {
      ob_end_clean();
    }
    // заставляем браузер показать окно сохранения файла
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    // читаем файл и отправляем его пользователю
    readfile($file);
    exit;
  }
}
function download_proxy($url)
{
	$fp = fopen('socks5_proxies.txt', 'wb'); // создаём и открываем файл для записи
	$ch = curl_init($url); // $url содержит прямую ссылку на видео
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FILE, $fp); // записать вывод в файл
	curl_exec($ch);
	curl_close($ch);
	fclose($fp);
}
?>