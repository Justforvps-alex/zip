<?php
session_start();
$_SESSION['proverka']='TEST';
echo $_SESSION['proverka'];
ob_flush();
ob_flush();
exit;
?>