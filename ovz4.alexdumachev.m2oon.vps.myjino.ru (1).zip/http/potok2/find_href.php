<?php
ignore_user_abort(true);
ini_set('max_execution_time', 86400);
set_time_limit(86400);
//ini_set('implicate_flush','On');
error_reporting(0);
$main_url=$_GET['url'];
$page_number=$_GET['p'];
$number_of_phones=$_GET['n'];
$phone_number=$_GET['phone'];
$page_number=100;
print('<form action="check_status.php" class="justify-content-center "><input style="margin-top:20px; width:100%; font-size:20px;" type="submit" name="status" value="Отслеживать состояние загрузки">
</form>');
ob_flush();
flush();
//Создание статусазапущено
$php_status = fopen('phpstatus.txt', 'w+');
fwrite($php_status, "run");
fclose($php_status);
$main_url=str_replace ('nedvizhimost','kvartiry/prodam-ASgBAgICAUSSA8YQ',$main_url);
$main_url=str_replace ('transport','avtomobili',$main_url);
$main_url=str_replace ('uslugi','predlozheniya_uslug/bytovye_uslugi-ASgBAgICAUSYC7CfAQ',$main_url);
$statusfp = fopen('status.txt', 'w+');
fwrite($statusfp, "0/$number_of_phones");
fclose($statusfp);
require_once 'simple_html_dom.php';
require_once 'classes.php';
require_once 'functions.php';
$url='https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all';
download_proxy($url);
$max_pages=100;
//$number_of_phones=1500; //vvodim post
$url='';
$fp = fopen('data.txt', 'a+');
$mistakes = fopen('mistakes.txt', 'a+');
fwrite($mistakes, date('l jS \of F Y h:i:s A'));
//$array0[0]=''; $array1[0]=''; $array2[0]='';
while($phone_number<=$number_of_phones)
{
    //Проверка сигналов
    $signal=htmlentities(file_get_contents("signal.txt"));
    if($signal=="stop")
    {
        $php_status = fopen('phpstatus.txt', 'w+');
        fwrite($php_status, "done");
        fclose($php_status);
        exit;
    }
	$url=$main_url.'?p='.$page_number;
			            $statusfp = fopen('status.txt', 'w+');
                    	fwrite($statusfp, "Разбираем ключи-завтравки(1) с $page_number страницы. Уже скачано $phone_number/$number_of_phones телефонов");
                    	fclose($statusfp);	
	fwrite($mistakes, $url);
	$time_sleep=rand(0,1);
	$html=Curl_avito($url,$time_sleep,$mistakes);
	//fwrite($mistakes, $html);
	foreach($html->find('div.index-root-2c0gs') as $html_div)
	{
	    $html=$html_div;
	}
	//echo "<br>nulevoy cicl<br>";
	fwrite($mistakes, 'nulevoy cicl');
	//echo $html;
	$write_id_file = fopen('id_array.txt', 'w+');
	foreach($html->find('div.snippet-horizontal') as $href_div)
	{
		$id=$href_div->attr['data-item-id'];
		if($id%2!=0)
		{
			$array0[$id].=$href_div->attr['data-pkey'];
			if($array0[$id]!='')
			{
			    $contact_number=0;
		    	foreach($href_div->find('a.snippet-link') as $href_to_check)
	    	    {$contact_number=$contact_number+1;  }	
		         if($contact_number==1)
		        {
                   fwrite($write_id_file, $id.",");
		    	    fwrite($mistakes, $id);
		        }
			}
		}
	}
//unset($html);
	fclose($write_id_file);
	$statusfp = fopen('status.txt', 'w+');
    fwrite($statusfp, "Разбираем ключи-завтравки(2) с $page_number страницы. Уже скачано $phone_number/$number_of_phones телефонов");
    fclose($statusfp);  
	//Собираем айди из файла, разбиваем на части
    $id_arrayall=htmlentities(file_get_contents("id_array.txt"));
    $id_array=preg_split("/[\s,]+/",$id_arrayall);
	$max_id=count($id_array);
    fwrite($mistakes, 'perviy cicl');
	$time_sleep=rand(0,1);
	$html=Curl_avito($url,$time_sleep,$mistakes);
	foreach($html->find('div.index-root-2c0gs') as $html_div)
	{
	    $html=$html_div;
	}
	//echo $html;
	
    //Проверка сигналов
    $signal=htmlentities(file_get_contents("signal.txt"));
    if($signal=="stop")
    {
        $php_status = fopen('phpstatus.txt', 'w+');
        fwrite($php_status, "done");
        fclose($php_status);
        exit;
    }
  
	for($id_numer=0;$id_numer<$max_id; $id_numer++)
	{
		$id=$id_array[$id_numer];
		foreach($html->find("div[data-item-id=$id]") as $href_div)
		{
		        if(isset($href_div)){$array1[$id].=$href_div->attr['data-pkey']; fwrite($mistakes, $id.") ".$array1[$id]."<br>");}
		}
	}
//unset($html);
	//echo "<br>vtoroy cicl<br>";
	fwrite($mistakes, 'vtoroy cicl');
	$checked_id=1;
	$time_sleep=rand(0,1);
	$html=Curl_avito($url,$time_sleep,$mistakes);
	foreach($html->find('div.index-root-2c0gs') as $html_div)
	{
	    $html=$html_div;
	}
	//echo $html;
	for($id_numer=0;$id_numer<$max_id; $id_numer++)
	{
	 //Проверка сигналов
    $signal=htmlentities(file_get_contents("signal.txt"));
    if($signal=="stop")
    {
    $php_status = fopen('phpstatus.txt', 'w+');
    fwrite($php_status, "done");
    fclose($php_status);
    exit;
    }
		$id=$id_array[$id_numer];
		foreach($html->find("div[data-item-id=$id]") as $href_div)
		{
		if(isset($href_div))
		{$array2[$id].=$href_div->attr['data-pkey']; fwrite($mistakes, $id.") ".$array2[$id]."<br>");}
		if($array0[$id]!='' && $array1[$id]!='' && $array2[$id]!='')
		{           
				    //echo "<br>Номер )",$id,"<br>";
	            	fwrite($mistakes, $checked_id."  Внутри ласт цикла   ".$phone_number.") ".$array0[$id]."   ".$array1[$id]."    ".$array2[$id]."    ");
            		$phone_item_only0=$array0[$id];
            		$phone_item_only1=$array1[$id];
            		$phone_item_only2=$array2[$id];
              		$url=find_phone_url($id, $phone_item_only0, $phone_item_only1, $phone_item_only2);
            		fwrite($mistakes, "<br>Фоне юрл".$checked_id.")".$url."<br>");
            		$time_sleep=rand(1,2);
            		$imgContent = Curl_avito($url,$time_sleep,$mistakes);
            		//echo "<br>".$imgContent."<br>";
            		$avitoContact = new AvitoContact;
            		$imgContent = explode('base64,', $imgContent)[1];
            		//echo "<br>".$imgContent."<br>";
                	$a = fopen('phone.png', 'wb');
                	fwrite($a, base64_decode($imgContent));
            		fclose($a);
	            	$image='phone.png';
	            	$result = $avitoContact->recognize('phone.png');
	            	if ($result) 
	            	{
	            	    //print("<p>Phone number: ".$result."</p>");
	            	    //flush();
	            	    //ob_flush();
	                 	fwrite($mistakes, "<br>Phone number: ".$result."<br>");
	                  	fwrite($fp, $result.",");
	                  	$statusfp = fopen('status.txt', 'w+');
                        fwrite($statusfp, "Разбираем картинки телефонов с $page_number страницы. Уже скачано $phone_number/$number_of_phones телефонов");
                        fclose($statusfp);
	                  	if($phone_number>=$number_of_phones)
	                  	{
	                  	    fwrite($mistakes, date('l jS \of F Y h:i:s A'));
                            fwrite($mistakes, "Exel");
                            //Создание статуса закончено
                            $php_status = fopen('phpstatus.txt', 'w');
                            fwrite($php_status, "done");
                            fclose($php_status);
                            fclose($fp);
                            fclose($mistakes);
                            $statusfp = fopen('status.txt', 'w+');
                            fwrite($statusfp, "Скачивание завершено, скачано $phone_number/$number_of_phones телефонов");
                            fclose($statusfp);
                            exit;
	                  	}
						$phone_number++;
	            	} 
	            	else 
                	{
                		fwrite($mistakes, '<h2 class="text-danger">Ничего не получилось</h2>');
	            	}
	            	$checked_id++;
                unset($array0[$id]);
                unset($array1[$id]);
                unset($array2[$id]);
	    	}
	    }
	}
unset($html);
fwrite($mistakes, date('l jS \of F Y h:i:s A'));
fwrite($mistakes, "Страница номер $page_number");
$page_number=$page_number-1;
}
?>
