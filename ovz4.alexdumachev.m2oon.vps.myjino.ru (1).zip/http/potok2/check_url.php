<?php
$main_url="https://www.avito.ru/nizhniy_tagil";
$url_validator=explode('/',$main_url)[4];
if($url_validator='' or $url_validator==NULL){echo "Невалидный URL";}
echo $url_validator;
$main_url=str_replace ('nedvizhimost','kvartiry/prodam-ASgBAgICAUSSA8YQ',$main_url);
$main_url=str_replace ('transport','avtomobili',$main_url);
$main_url=str_replace ('uslugi','predlozheniya_uslug/bytovye_uslugi-ASgBAgICAUSYC7CfAQ',$main_url);
echo $main_url;
?>